package SimulacionAeropuerto;
public class Avion2 implements Runnable {
    public void run() {
        System.out.println("Avión 2: Aterrizando.");
        // Simulación del proceso de aterrizaje (puedes agregar más lógica aquí si es necesario)
        try {
            Thread.sleep(3000); // Simular tiempo de aterrizaje
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Avión 2: Ha aterrizado.");
    }
}
