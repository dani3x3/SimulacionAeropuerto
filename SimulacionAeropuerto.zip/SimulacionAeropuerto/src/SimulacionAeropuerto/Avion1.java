package SimulacionAeropuerto;
public class Avion1 implements Runnable {
    public void run() {
        System.out.println("Avión 1: Despegando.");
        // Simulación del proceso de despegue (puedes agregar más lógica aquí si es necesario)
        try {
            Thread.sleep(2000); // Simular tiempo de despegue
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("Avión 1: Ha despegado.");
    }
}
