package SimulacionAeropuerto;
public class Main {
    public static void main(String[] args) {
        // Crear instancias de los hilos
        Thread avion1 = new Thread(new Avion1());
        Thread avion2 = new Thread(new Avion2());

        // Iniciar los hilos
        avion1.start();
        avion2.start();
    }
}
